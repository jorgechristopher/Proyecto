<?php
$conexion = mysql_connect("host", "user", "pass") or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_select_db("bd", $conexion);
?>