<?php
require("conexion.php");
// insertarmos el registro
mysql_query("INSERT INTO empresa (nombre, direccion, telefono) VALUES ('Apple', '1 Infinite Loop, Cupertino', 899610)");
// obtenemos el ID del registro
echo mysql_insert_id();
?>